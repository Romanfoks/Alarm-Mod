ServerEvents.recipes(event => {
    event.remove({ id: 'minecraft:blue_dye' })
    event.remove({ id: 'create:milling/lapis_lazuli' })

    event.custom({
        type: 'powergrid:magnetization',
        ingredients: [
            { item: 'alarmmod:redstone_iron' }
        ],
        results: [
            { id: 'alarmmod:redstone_charged_iron'}
        ]
    })
    event.shapeless(
        Item.of('minecraft:blue_dye', 1), // arg 1: output
        [
            'alarmmod:lapis_dust'
        ]
    )
    event.recipes.create.milling(['alarmmod:lapis_dust', CreateItem.of('alarmmod:lapis_dust', 0.1)], 'minecraft:lapis_lazuli')
    event.recipes.create.mixing([Fluid.of('kubejs:lazulite_acid')], [Fluid.of('minecraft:water'), Ingredient.of('alarmmod:lapis_dust',15)])
    event.recipes.create.mixing([Fluid.of('kubejs:redstone_acid')], [Fluid.of('kubejs:lazulite_acid'), Ingredient.of('minecraft:redstone',15)])
    event.recipes.create.mixing(['alarmmod:redstone_iron'], [Ingredient.of('minecraft:iron_ingot'),Fluid.of('kubejs:redstone_acid',100)])

    event.shaped('alarmmod:alarm', [
        'AAA',
        'ACA',
        'BBB'
    ], {
        A: 'minecraft:red_stained_glass_pane',
        B: 'minecraft:black_concrete',
        C: 'alarmmod:redstone_charged_iron'
    })

})